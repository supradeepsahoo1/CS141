#include <iostream>
using namespace std;

class Node
{ 
   int num;
   Node *next;
}
